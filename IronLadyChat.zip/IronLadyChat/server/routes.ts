import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateChatResponse } from "./services/openai.js";
import { insertChatSessionSchema, insertChatMessageSchema } from "@shared/schema";
import { randomUUID } from "crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Create chat session
  app.post("/api/chat/sessions", async (req, res) => {
    try {
      const sessionId = randomUUID();
      const session = await storage.createChatSession({ sessionId });
      res.json({ sessionId: session.sessionId });
    } catch (error) {
      console.error("Error creating chat session:", error);
      res.status(500).json({ message: "Failed to create chat session" });
    }
  });

  // Send message and get AI response
  app.post("/api/chat/messages", async (req, res) => {
    try {
      const { sessionId, message } = req.body;

      if (!sessionId || !message) {
        return res.status(400).json({ message: "Session ID and message are required" });
      }

      // Validate session exists
      const session = await storage.getChatSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Chat session not found" });
      }

      // Save user message
      const userMessage = await storage.createChatMessage({
        sessionId,
        content: message,
        isUser: true
      });

      // Get conversation history for context
      const history = await storage.getChatMessages(sessionId);
      const conversationHistory = history
        .slice(-10) // Last 10 messages for context
        .map(msg => ({
          role: msg.isUser ? "user" : "assistant",
          content: msg.content
        }));

      // Generate AI response
      const aiResponseContent = await generateChatResponse(message, conversationHistory);

      // Save AI response
      const aiMessage = await storage.createChatMessage({
        sessionId,
        content: aiResponseContent,
        isUser: false
      });

      res.json({
        userMessage,
        aiMessage,
        response: aiResponseContent
      });

    } catch (error) {
      console.error("Error processing chat message:", error);
      res.status(500).json({ 
        message: "I apologize, but I'm experiencing technical difficulties. Please try again or visit iamironlady.com for more information." 
      });
    }
  });

  // Get chat history
  app.get("/api/chat/sessions/:sessionId/messages", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessages(sessionId);
      res.json({ messages });
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      service: "Iron Lady AI Assistant",
      timestamp: new Date().toISOString()
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
