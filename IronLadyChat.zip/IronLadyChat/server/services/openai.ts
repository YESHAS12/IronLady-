import OpenAI from "openai";
import { knowledgeBase, searchKnowledgeBase } from "./knowledgeBase.js";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export async function generateChatResponse(message: string, conversationHistory: any[] = []): Promise<string> {
  try {
    // First check knowledge base for quick responses
    const knowledgeResponse = searchKnowledgeBase(message);
    if (knowledgeResponse) {
      return knowledgeResponse;
    }

    // Use OpenAI for more complex queries
    const systemPrompt = `You are an AI assistant for Iron Lady, a women's leadership development organization in India. You help women learn about our leadership programs and provide guidance.

ABOUT IRON LADY:
- We've trained 78,000+ women leaders and currently train 4,000 women monthly
- We focus on "Business War Tactics" to help women win without fighting
- We address stereotypes, biases, and workplace politics that women face
- Our approach emphasizes unapologetic ambition and breakthrough growth

OUR PROGRAMS:
1. Leadership Essentials Program (LEP) - TISS certified
   - For professionals feeling guilty about being ambitious
   - Learn shameless pitching and deal with office politics
   - Build unapologetic winning mindset

2. 100 Board Members Program - NSDC certified  
   - For women stuck at the same career level
   - Innovative techniques for fast-track growth
   - Targeting board-ready positions

3. Master of Business Warfare (MBW) - NASSCOM certified
   - For C-suite aspirants targeting 1+ Crore income
   - Advanced business warfare tactics
   - Premium executive coaching

OUR MENTORS:
- Simon Newman (Ex-CEO, Aviva Singapore)
- Sridhar Sambandam (Ex-CEO, Bajaj Auto)  
- Suvarna Hegde (Founder & CEO)
- Rajesh Bhat (Founder/Director, TEDx Speaker)

PROGRAM FEATURES:
- Mixed format (online + offline)
- One-on-one personalized coaching
- Real-world practical projects
- Lifetime community access
- Prestigious certifications

Always be encouraging, professional, and focused on women's empowerment. Provide specific program recommendations based on user needs. If asked about pricing or enrollment, direct them to visit iamironlady.com or speak with a counselor.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: systemPrompt },
        ...conversationHistory,
        { role: "user", content: message }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I apologize, but I'm having trouble generating a response right now. Please try asking about our programs, duration, certification, or mentors.";

  } catch (error) {
    console.error('OpenAI API Error:', error);
    
    // Fallback to knowledge base response
    const fallbackResponse = searchKnowledgeBase(message);
    if (fallbackResponse) {
      return fallbackResponse;
    }

    // Ultimate fallback
    return `I understand you're asking about "${message}". While I'm experiencing some technical difficulties, I can still help you with information about Iron Lady's programs.

**Quick Information:**
• **Programs**: Leadership Essentials, 100 Board Members, Master of Business Warfare
• **Format**: Mixed (Online + Offline) 
• **Certification**: TISS, NSDC, NASSCOM certified
• **Mentors**: Industry veterans including ex-CEOs from Aviva Singapore and Bajaj Auto
• **Community**: 78,000+ women leaders

For detailed information, please visit iamironlady.com or ask me specific questions about our programs!`;
  }
}

export async function generateProgramRecommendation(userProfile: string): Promise<{
  program: string;
  reasoning: string;
  nextSteps: string;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are an Iron Lady program advisor. Based on user profile, recommend the best program and provide reasoning. Respond in JSON format with: { "program": "program_name", "reasoning": "why_this_program", "nextSteps": "what_to_do_next" }`
        },
        {
          role: "user",
          content: `Based on this profile, which Iron Lady program would you recommend: ${userProfile}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return {
      program: result.program || "Leadership Essentials Program",
      reasoning: result.reasoning || "This program provides foundational leadership skills perfect for your current stage.",
      nextSteps: result.nextSteps || "Visit iamironlady.com to learn more and speak with our counselors."
    };
  } catch (error) {
    console.error('Program recommendation error:', error);
    return {
      program: "Leadership Essentials Program", 
      reasoning: "This foundational program is perfect for building leadership confidence and skills.",
      nextSteps: "Visit iamironlady.com to explore program details and connect with our team."
    };
  }
}
