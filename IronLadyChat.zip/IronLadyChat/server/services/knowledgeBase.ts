export interface ProgramInfo {
  name: string;
  description: string;
  duration: string;
  format: string;
  certification: string;
  target: string;
}

export const knowledgeBase = {
  programs: {
    "leadership essentials program": {
      name: "Leadership Essentials Program (LEP)",
      description: "Master Business War Tactics like 'shameless pitching', 'strategic maximization', and 'unapologetic mindset', 'Crucibles of Leadership', and 'Strength Based Excellence' through a comprehensive 4-week program, and 1-year community learning.",
      fullDescription: "Is the ideology of 'Learn to Balance' imposed on you? Made to feel 'Guilty' for dreaming? Is politics / bias becoming unbearable? Unfortunately, in most places, women earn only 50-90% of what men earn for the same JOB! Leadership Essentials Program enables you to master Business War Tactics.",
      duration: "4-week intensive program + 1-year community membership",
      structure: "2 full days (Saturday and Sunday, 9am-7pm) + weekly challenges and progress review sessions for four weeks (approx. 1.5 hrs weekly) + daily leadership activities (10 mins per day)",
      format: "Online Live sessions on ZOOM + community networking + recorded videos/templates",
      certification: "TISS (Tata Institute of Social Sciences) certified",
      price: "₹35,000/- + GST (Scholarship available)",
      target: "Women committed to grow faster in career or business, dealing with bias/politics/glass ceiling, looking for mentorship and community",
      modules: ["Building the Belief of a Leader, connecting with Mentors and buddies", "Practicing Business War Tactics, Shameless Pitching!", "Maximizing over Balancing! Managing Time like a Leader", "Building Your Extraordinary Differentiated Brand"],
      outcomes: ["Personal Transformation through crucibles of leadership", "BHAG–based approach for fast-track growth", "Personal Branding Resources: Social Profile, Resume, Leadership Persona", "Personal Strengths and Weaknesses Assessment Report", "Personalized Skill-building Roadmap", "Understanding Maximization vs Balance", "Guiding Stars – Leadership habits", "Iron Lady Certification"],
      methodology: ["Dedicated mentor for 15-20 people", "High impact practice sessions for mastering 27 Business War Tactics", "Buddies and accountability system", "1-year community networking", "Daily short activities", "Private, non-recorded sessions", "Recorded videos/templates"],
      testimonials: [
        { name: "Bharti Mohan", quote: "The Iron Lady Program was very effective and I used the principles learnt to win my UN Ambassador Crown." },
        { name: "Rishika Sood", quote: "Before Iron Lady, I was very low on confidence. Even after being a high performer, I was told I am not up to the mark. Iron Lady helped me regain my confidence and be a better version of myself." },
        { name: "Shalet Roy", quote: "The sessions were very intensive and useful. It was specially helpful for women like me who were on a break and returning to work." }
      ]
    },
    "100 board members program": {
      name: "100 Board Members Program",
      description: "Fast Track your growth towards TOP Management using Business War Tactics and Upside-down thinking! Designed for professionals with 7+ years of experience looking for fast track growth.",
      fullDescription: "Are you stuck amidst gender biases, politics and stereotypes at workplace leading to no growth? Higher you try to reach, more challenging it becomes? Enroll for our 100 Board Members Program to Fast Track your growth towards TOP Management.",
      duration: "6 months overall duration",
      structure: "6 half day live sessions over first 4 months + rigorous practice and implementation for last 2 months + bi-weekly practice sessions (45-60 mins) throughout 6 months",
      format: "Experiential cohort based activities + sessions from top board members/investors + various huddles and practice sessions",
      certification: "NSDC (National Skill Development Corporation) certified",
      price: "₹75,000/- + GST (Scholarship available)",
      target: "Professionals with 7+ years experience, keen to reach TOP management in 3-5 years, looking for BIG pay jump, business owners/doctors/lawyers looking to scale",
      modules: ["Build the brand/image of a Board Member", "Operational excellence at board levels", "Breakthrough Capability Development", "Influencing through extreme signalling", "Strategic Excellence at board levels", "Transformation from Functional leadership to business leadership"],
      outcomes: ["Clear roadmap to fast-track growth", "Differentiated Leadership Brand positioning as TOP Leader", "Strategic mindset and tactics for tough challenges", "Transformational Capabilities for higher level roles", "Tricks and techniques to avoid pitfalls"],
      methodology: ["Experiential cohort based activities", "Sessions from top board members/investors", "Various huddles and activity sessions", "Case studies and mock pitches", "Online, closed room, confidential sessions"],
      testimonials: [
        { name: "Harvinder Kaur", quote: "As the CFO of Rajasthan Royals IPL Team I was able to deal with every possible challenge with confidence and ease! Though I was the only woman member of the team, I was able to deal with every challenge that came my way." },
        { name: "Anu Kannan", quote: "Building my profile as a Board Member enabled me to bag a new role with 170% hike as Vice-President, at Bank of America! I could present myself confidently at two levels higher and do justice to it as well!" },
        { name: "Sushma Patil", quote: "Capabilities that others develop in 10-12 years, I could develop just 6 months! This enabled me to increase my CTC by 100% just in 8 months!" }
      ]
    },
    "master of business warfare": {
      name: "Master of Business Warfare (MBW)",
      description: "Cutting-edge business warfare tactics for C-suite breakthrough and achieving 1+ Crore income goals. Advanced strategies for committed professionals ready to reach the top.",
      fullDescription: "The most advanced program for women targeting C-suite positions and 1+ Crore income breakthrough. Combines cutting-edge business warfare tactics with strategic leadership development.",
      duration: "Intensive executive program with premium mentoring and ongoing strategic support",
      format: "Premium mixed format with personalized executive coaching and strategic sessions",
      certification: "NASSCOM Foundation certified",
      target: "Senior professionals and executives committed to reaching C-suite positions and 1+ Crore income bracket",
      exclusivity: "Highly selective program for committed C-suite aspirants"
    }
  },
  general: {
    ecosystem: "Join our community of 78,000+ women leaders. We currently train 4,000 women monthly through our comprehensive programs.",
    format: "Iron Lady offers both online and offline programs using a mixed format approach. This combines the flexibility of online learning with the personal touch of face-to-face interaction.",
    certificates: "All Iron Lady programs provide certificates from prestigious institutions: TISS (Tata Institute of Social Sciences), NSDC (National Skill Development Corporation), and NASSCOM Foundation.",
    mission: "ELEVATING A MILLION WOMEN TO THE TOP",
    company: "A unit of Magic Wand Empowerment Private Limited",
    founding: "Iron Lady was created in 2016-17 by Suvarna Hegde",
    focus: "India's leading women's leadership development organization",
    uniqueApproach: "Business War Tactics to help women win without fighting, addressing stereotypes, biases, and workplace politics",
    philosophy: "We believe in empowering women to be unapologetically ambitious. Our approach focuses on 'winning' without others needing to lose - it's about elevation, not competition. We challenge the ideology of 'Learn to Balance' and help women develop unapologetic mindset.",
    payGap: "Unfortunately, in most places, women earn only 50-90% of what men earn for the same job. Iron Lady addresses this inequality.",
    recognition: "4.8/5 Google rating from 512+ reviews",
    mentors: [
      {
        name: "Rajesh Bhat",
        title: "Founder & Director, TEDx Speaker",
        background: "Visionary entrepreneur who has led three groundbreaking startups: Head Held High, 1Bridge, and Iron Lady. His unconventional leadership style and commitment to gender equality have gained global recognition. His bold choice to wear a saree in professional settings has sparked conversations and challenged stereotypes. Earned accolades from Amitabh Bachchan and CNN, who named him one of 'The Real Heroes of India.'"
      },
      {
        name: "Suvarna Hegde",
        title: "Founder & CEO, Iron Lady",
        background: "One of the foremost experts of Business War Tactics for Women. She has coached hundreds of Founders/CEOs and thousands of women leaders to reach the TOP. As an innovation specialist, she has created multiple mega Technology Projects in well-known companies like Infosys, Robert Bosch and Philips, before starting Iron Lady."
      },
      {
        name: "Simon Newman",
        title: "Co-Founder, Chairman",
        background: "Highly accomplished global CEO/CXO – being the CEO of companies like Aviva, Singapore. He's held CXO positions at Barclays, Prudential and Hong Leong Bank. Simon has mentored/managed/supported thousands of senior leaders over his illustrious career spanning over 3 decades."
      },
      {
        name: "Sridhar Sambandam", 
        title: "Co-Founder, Director",
        background: "Considered one of the foremost turn-around specialists in India, having turned around many billion-dollar companies like Bajaj Auto and Escorts, being their CEO/president. Comes with 25+ years of corporate experience. Coaches many CEOs/entrepreneurs of large companies today. Specialist in the Bing-Fa and Art of War corporate breakthrough performance methodologies."
      },
      {
        name: "Chitra Talwar",
        title: "Investor, Board Member and Advisor: Social Impact Champion",
        background: "Over three decades of global experience in the FMCG sector. Held key leadership positions at Britannia and PepsiCo across Sales, Marketing, and General Management in both Indian and international markets. Based in New York, retired as Vice President, International Sales Operations at PepsiCo, NY. Gold Medalist graduate in Economics from Madras University and MBA from XLRI (Class of 1976)."
      }
    ],
    approach: "We focus on 'Business War Tactics' to help women win without fighting, addressing stereotypes, biases, and workplace politics that women face daily.",
    features: [
      "One-on-one personalized coaching",
      "Real-world application through practical projects",
      "Peer networking with ambitious professionals", 
      "Ongoing community support post-program",
      "Access to 78,000+ women leaders ecosystem",
      "27 Business War Tactics mastery",
      "Strength-based excellence development",
      "BHAG (Big Hairy Audacious Goal) methodology",
      "Crucibles of Leadership training",
      "Strategic maximization over balancing"
    ],
    businessWarTactics: [
      "Shameless pitching",
      "Strategic maximization",
      "Unapologetic mindset",
      "Extreme signalling for influence",
      "Upside-down thinking",
      "Operational excellence at board levels",
      "Strategic excellence for leadership",
      "Breakthrough capability development",
      "Transformational leadership capabilities",
      "Differentiated leadership brand building"
    ],
    targetAudience: [
      "Professionals aspiring for growth",
      "Entrepreneurs and business women",
      "Women seeking career change or restart",
      "Mid to senior-level professionals targeting C-suite",
      "Business owners, doctors, lawyers looking to scale",
      "Women dealing with bias, politics, glass ceiling",
      "Professionals with 7+ years experience seeking fast-track growth"
    ],
    successMetrics: [
      "Women reaching 1+ Crore income brackets",
      "170% salary hikes achieved",
      "100% CTC increases in 8 months",
      "Board-level position achievements",
      "Business scaling and operational growth",
      "UN Ambassador Crown wins",
      "CFO roles at major companies (Rajasthan Royals IPL)",
      "Vice-President roles at Bank of America"
    ]
  },
  detailedTestimonials: [
    { name: "Pushpalatha M.S", quote: "Iron Lady Program helped me and my co-founder Dr. Asha Vijay to scale our operations. All thanks to Rajesh and his team at Iron lady. Highly recommend iron Lady to all the women.", category: "Business Scaling" },
    { name: "Minal Bhagat", quote: "I was surprised that even the online medium could be so effective and impactful. I am already being shameless and achieving many breakthroughs.", category: "Mindset Transformation" },
    { name: "Vinath Hegde", quote: "The Iron Program was very effective and I used the principles to win my UN Ambassador Crown. The program and it's purpose is very dear to my heart.", category: "Leadership Achievement" },
    { name: "Harvinder Kaur", quote: "As the CFO of Rajasthan Royals IPL Team I was able to deal with every possible challenge with confidence and ease! Though I was the only woman member of the team, I was able to deal with every challenge that came my way.", category: "C-Suite Success" },
    { name: "Anu Kannan", quote: "Building my profile as a Board Member enabled me to bag a new role with 170% hike as Vice-President, at Bank of America! I could present myself confidently at two levels higher and do justice to it as well!", category: "Career Breakthrough" },
    { name: "Sushma Patil", quote: "Capabilities that others develop in 10-12 years, I could develop just 6 months! This enabled me to increase my CTC by 100% just in 8 months!", category: "Fast-Track Growth" },
    { name: "Dr. Darshana Vithalani", quote: "Leadership Essential Program is unique in its approach of weeding off unempowering beliefs, breaking past conditioning and enabling women to think and act beyond their perceived limitations.", category: "Personal Transformation" },
    { name: "Sunila Nambiar", quote: "I think I made a good decision joining the Iron Lady Leadership Essentials program. From the program, I feel that I am in a much better position to handle challenges.", category: "Confidence Building" },
    { name: "Veda Prasad", quote: "Taking up the Iron Lady Leadership Program during my career break was one of the best decisions I've made. Over the course of the program, I gained clarity on my goals and developed the confidence to pursue them.", category: "Career Restart" },
    { name: "Nandita Roy Baul", quote: "Iron Lady truly lives up to its name, empowering me to believe in myself, even at this stage in life. It's given me the confidence to dream bigger and take bold steps.", category: "Life Transformation" },
    { name: "Bharti Mohan", quote: "The Iron Lady Program was very effective and I used the principles learnt to win my UN Ambassador Crown.", category: "Achievement" },
    { name: "Rishika Sood", quote: "Before Iron Lady, I was very low on confidence. Even after being a high performer, I was told I am not up to the mark. Iron Lady helped me regain my confidence and be a better version of myself.", category: "Confidence Recovery" },
    { name: "Shalet Roy", quote: "The sessions were very intensive and useful. It was specially helpful for women like me who were on a break and returning to work.", category: "Career Return" }
  ]
};

export function searchKnowledgeBase(query: string): string {
  const lowerQuery = query.toLowerCase();
  
  // Greeting queries
  if (lowerQuery.includes('hello') || lowerQuery.includes('hi') || lowerQuery.includes('hey') || lowerQuery.includes('good morning') || lowerQuery.includes('good afternoon')) {
    return `Hello! 👋 Welcome to Iron Lady! I'm here to help you discover our leadership programs for women.

I can answer questions about:
• **Programs** - Our 3 flagship leadership programs
• **Duration & Format** - Online, offline, and mixed learning options
• **Certification** - TISS, NSDC, and NASSCOM certifications
• **Mentors** - Ex-CEOs and industry leaders
• **Community** - Our 78,000+ women leaders ecosystem

What would you like to know about Iron Lady's leadership development programs?`;
  }

  // About Iron Lady queries
  if (lowerQuery.includes('about') || lowerQuery.includes('iron lady') || lowerQuery.includes('company') || lowerQuery.includes('organization')) {
    return `**About Iron Lady:**

Iron Lady is India's leading women's leadership development organization, dedicated to **"ELEVATING A MILLION WOMEN TO THE TOP"**.

🏆 **Our Impact:**
• Trained 78,000+ women leaders across India
• Currently training 4,000 women monthly
• Focus on breakthrough, fast-track growth strategies

💪 **Our Unique Approach:**
• **Business War Tactics** - Win without fighting
• Address stereotypes, biases, and workplace politics
• Develop unapologetic ambition and winning mindset
• Breakthrough results in smallest possible time

🌟 **What Sets Us Apart:**
• Combine practical strategies with mindset transformation
• Non-judgmental community of ambitious women
• Real-world application through experienced mentors
• Prestigious certifications from TISS, NSDC, NASSCOM

Ready to fast-track your leadership journey?`;
  }

  // Success stories and testimonials
  if (lowerQuery.includes('success') || lowerQuery.includes('testimonial') || lowerQuery.includes('review') || lowerQuery.includes('result')) {
    return `**Success Stories from Iron Lady Women:**

🌟 **Pushpalatha M.S** - "Iron Lady Program helped me and my co-founder Dr. Asha Vijay to scale our operations. Highly recommend Iron Lady to all women."

🌟 **Minal Bhagat** - "I was surprised that even the online medium could be so effective and impactful. I am already being shameless and achieving many breakthroughs."

🌟 **Vinath Hegde** - "The Iron Program was very effective and I used the principles to win my UN Ambassador Crown. The program and its purpose is very dear to my heart."

🌟 **Dr. Darshana Vithalani** - "Leadership Essential Program is unique in its approach of weeding off unempowering beliefs, breaking past conditioning."

**Our Google Reviews:** 4.8/5 rating from 512+ reviews

**Real Results:**
• Women reaching 1+ Crore income brackets
• Career transformations and promotions
• Business scaling and growth
• Enhanced confidence and leadership skills

Which program interests you for your transformation journey?`;
  }

  // Cost and pricing queries
  if (lowerQuery.includes('cost') || lowerQuery.includes('price') || lowerQuery.includes('fee') || lowerQuery.includes('payment') || lowerQuery.includes('money')) {
    return `**Investment in Your Leadership Journey:**

For detailed pricing information and payment options, I recommend speaking directly with our counselors who can:

• **Understand your specific career goals**
• **Recommend the best program for your needs**
• **Discuss flexible payment options**
• **Provide current pricing details**

📞 **Next Steps:**
• Visit iamironlady.com for more information
• Book a consultation with our program counselors
• They'll help you choose the right investment for your career transformation

Remember: This is an investment in your leadership future and career growth. Our programs have helped women achieve 1+ Crore income breakthroughs!

Would you like to know more about any specific program first?`;
  }

  // Enrollment and how to join
  if (lowerQuery.includes('enroll') || lowerQuery.includes('join') || lowerQuery.includes('apply') || lowerQuery.includes('admission') || lowerQuery.includes('register')) {
    return `**How to Join Iron Lady Programs:**

🚀 **Simple Enrollment Process:**

**Step 1: Program Discovery**
• Explore our 3 flagship programs
• Understand which aligns with your goals

**Step 2: Counselor Consultation** 
• Speak with our program counselors
• Get personalized program recommendations
• Discuss your career aspirations

**Step 3: Program Selection**
• Choose between LEP, 100 Board Members, or MBW
• Review program details and investment

**Step 4: Enrollment**
• Complete registration process
• Begin your transformation journey

📞 **Ready to Start?**
• Visit iamironlady.com
• Speak to our counselors for guidance
• Not sure which program? Ask me about each one!

**Quick Program Overview:**
• **LEP** - Build unapologetic ambition
• **100 Board Members** - Fast-track career growth  
• **MBW** - C-suite strategies for 1+ Crore income

Which program interests you most?`;
  }

  // Specific program queries - LEP
  if (lowerQuery.includes('leadership essentials') || lowerQuery.includes('lep')) {
    const lep = knowledgeBase.programs["leadership essentials program"];
    return `**Leadership Essentials Program (LEP) - Complete Details:**

${lep.fullDescription}

**🎯 Program Structure:**
• **Duration:** ${lep.duration}
• **Format:** ${lep.format}
• **Price:** ${lep.price}
• **Certification:** ${lep.certification}

**📚 4 Core Modules:**
${lep.modules?.map((module, i) => `${i + 1}. ${module}`).join('\n')}

**🚀 Program Outcomes:**
${lep.outcomes?.map(outcome => `• ${outcome}`).join('\n')}

**💪 Methodology:**
${lep.methodology?.map(method => `• ${method}`).join('\n')}

**👥 Perfect for:** ${lep.target}

**💬 Success Stories:**
${lep.testimonials?.map(t => `"${t.quote}" - ${t.name}`).join('\n\n')}

Ready to master 27 Business War Tactics? Visit iamironlady.com to apply!`;
  }

  // Specific program queries - 100 Board Members
  if (lowerQuery.includes('100 board') || lowerQuery.includes('board members')) {
    const board = knowledgeBase.programs["100 board members program"];
    return `**100 Board Members Program - Complete Details:**

${board.fullDescription}

**🎯 Program Structure:**
• **Duration:** ${board.duration}
• **Format:** ${board.format}
• **Price:** ${board.price}
• **Certification:** ${board.certification}

**📚 6 Strategic Modules:**
${board.modules?.map((module, i) => `${i + 1}. ${module}`).join('\n')}

**🚀 Program Outcomes:**
${board.outcomes?.map(outcome => `• ${outcome}`).join('\n')}

**💪 Methodology:**
${board.methodology?.map(method => `• ${method}`).join('\n')}

**👥 Perfect for:** ${board.target}

**💬 Incredible Results:**
${board.testimonials?.map(t => `"${t.quote}" - ${t.name}`).join('\n\n')}

Ready to fast-track to TOP management? Download brochure at iamironlady.com!`;
  }

  // Specific program queries - MBW
  if (lowerQuery.includes('master of business warfare') || lowerQuery.includes('mbw') || lowerQuery.includes('c-suite') || lowerQuery.includes('crore')) {
    const mbw = knowledgeBase.programs["master of business warfare"];
    return `**Master of Business Warfare (MBW) - Elite Program:**

${mbw.fullDescription}

**🎯 Program Highlights:**
• **Duration:** ${mbw.duration}
• **Format:** ${mbw.format}
• **Certification:** ${mbw.certification}
• **Exclusivity:** ${mbw.exclusivity}

**👥 Target Audience:** ${mbw.target}

**🏆 This is Iron Lady's most advanced program for:**
• Women targeting C-suite positions
• Professionals aiming for 1+ Crore income breakthrough
• Senior executives ready for ultimate transformation
• Leaders committed to reaching the absolute top

**💡 Advanced Business War Tactics:**
${knowledgeBase.general.businessWarTactics.slice(0, 5).map(tactic => `• ${tactic}`).join('\n')}

The MBW program represents the pinnacle of Iron Lady's offerings - designed for women who are absolutely committed to reaching the C-suite and achieving 1+ Crore income goals.

Ready for the ultimate breakthrough? Contact counselors at iamironlady.com!`;
  }

  // General program queries
  if (lowerQuery.includes('programs') || (lowerQuery.includes('what') && lowerQuery.includes('offer'))) {
    return `**Iron Lady's Complete Program Portfolio:**

**🥇 1. Leadership Essentials Program (LEP)**
• ${knowledgeBase.programs["leadership essentials program"].description}
• **Duration:** 4 weeks + 1 year community
• **Price:** ₹35,000 + GST
• **Certification:** TISS Certified

**🥈 2. 100 Board Members Program**
• ${knowledgeBase.programs["100 board members program"].description}
• **Duration:** 6 months comprehensive
• **Price:** ₹75,000 + GST
• **Certification:** NSDC Certified

**🥉 3. Master of Business Warfare (MBW)**
• ${knowledgeBase.programs["master of business warfare"].description}
• **Duration:** Intensive executive program
• **Certification:** NASSCOM Certified

**🌟 All Programs Include:**
• Prestigious certifications from top institutions
• Expert mentorship from ex-CEOs
• Access to 78,000+ women leaders community
• Practical Business War Tactics training
• Real-world application and results

**📊 Success Metrics:**
${knowledgeBase.general.successMetrics.slice(0, 4).map(metric => `• ${metric}`).join('\n')}

Which program matches your career goals? Ask me for detailed information about any specific program!`;
  }

  // Duration queries
  if (lowerQuery.includes('duration') || lowerQuery.includes('long') || lowerQuery.includes('time')) {
    return `Our programs are designed for comprehensive transformation with flexible timelines:

**Program Structure:**
• Structured Learning Modules - Core content delivered over several weeks
• Ongoing Mentorship - Continued 1-on-1 coaching beyond program completion  
• Community Access - Lifetime access to our 78,000+ women leaders ecosystem
• Practical Implementation - Real-world projects and application support

**Key Features:**
${knowledgeBase.general.features.map(feature => `• ${feature}`).join('\n')}

The exact timeline varies by program intensity. Would you like specific details about any particular program?`;
  }

  // Format queries
  if (lowerQuery.includes('online') || lowerQuery.includes('offline') || lowerQuery.includes('format')) {
    return `Iron Lady uses a strategic **mixed format** approach for maximum impact:

**Online Components:**
• Interactive learning modules and digital content
• Virtual mentoring and coaching sessions  
• 24/7 community platform access
• Self-paced learning materials

**Offline Components:**
• In-person workshops and masterclasses
• Networking events and peer connections
• Practical application sessions
• Face-to-face mentoring meetings

${knowledgeBase.general.format}

This approach ensures you get both flexibility and personal connection. We currently train 4,000 women monthly through our comprehensive program delivery.`;
  }

  // Certificate queries
  if (lowerQuery.includes('certificate') || lowerQuery.includes('certification') || lowerQuery.includes('certified')) {
    return `**Yes! All Iron Lady programs provide prestigious certifications:**

🏆 **Leadership Essentials Program** - TISS Certified
🏆 **100 Board Members Program** - NSDC Certified  
🏆 **Master of Business Warfare** - NASSCOM Certified

**About Our Certification Partners:**
• **TISS** - Tata Institute of Social Sciences (Premier social sciences institution)
• **NSDC** - National Skill Development Corporation (Government of India initiative)
• **NASSCOM Foundation** - Leading IT industry body and social impact arm

These certificates carry significant weight with employers and institutions across India and internationally, validating your leadership development journey.`;
  }

  // Business War Tactics specific queries
  if (lowerQuery.includes('business war tactics') || lowerQuery.includes('tactics') || lowerQuery.includes('shameless') || lowerQuery.includes('maximization')) {
    return `**Iron Lady's Signature Business War Tactics:**

**🎯 Core Philosophy:** Help women win without fighting by addressing stereotypes, biases, and workplace politics that women face daily.

**💪 Key Business War Tactics We Teach:**
${knowledgeBase.general.businessWarTactics.map(tactic => `• **${tactic}**`).join('\n')}

**🚀 What Makes These Tactics Unique:**
• **Shameless Pitching** - Learn to present yourself and your ideas confidently without guilt
• **Strategic Maximization** - Focus on maximizing potential rather than "balancing" 
• **Unapologetic Mindset** - Develop unwavering confidence in your ambitions
• **Extreme Signalling** - Master the art of influential communication
• **Upside-down Thinking** - Challenge conventional approaches for breakthrough results

**🎓 Master All 27 Business War Tactics in LEP:**
Our Leadership Essentials Program specifically focuses on mastering all 27 Business War Tactics through high-impact practice sessions.

**📈 Real Results from Business War Tactics:**
• 170% salary increases
• Board-level position achievements  
• 1+ Crore income breakthroughs
• C-suite role successes

Ready to master these game-changing tactics? Explore our programs!`;
  }

  // Mentor queries with detailed backgrounds
  if (lowerQuery.includes('mentor') || lowerQuery.includes('coach') || lowerQuery.includes('who') || lowerQuery.includes('team') || lowerQuery.includes('founder')) {
    return `**Meet Iron Lady's World-Class Leadership Team:**

**🚀 RAJESH BHAT - Founder & Director, TEDx Speaker**
${knowledgeBase.general.mentors.find(m => m.name === "Rajesh Bhat")?.background}

**👑 SUVARNA HEGDE - Founder & CEO**
${knowledgeBase.general.mentors.find(m => m.name === "Suvarna Hegde")?.background}

**💼 SIMON NEWMAN - Co-Founder, Chairman**
${knowledgeBase.general.mentors.find(m => m.name === "Simon Newman")?.background}

**🎯 SRIDHAR SAMBANDAM - Co-Founder, Director**
${knowledgeBase.general.mentors.find(m => m.name === "Sridhar Sambandam")?.background}

**🌟 CHITRA TALWAR - Investor, Board Member & Advisor**
${knowledgeBase.general.mentors.find(m => m.name === "Chitra Talwar")?.background}

**🏆 What Makes Our Mentoring Unique:**
${knowledgeBase.general.features.map(feature => `• ${feature}`).join('\n')}

**🌍 Combined Experience:**
• 100+ years of collective C-suite experience
• Global leadership across major corporations
• Expertise in turning around billion-dollar companies
• Track record of mentoring thousands of senior leaders
• Specialists in Business War Tactics and breakthrough performance

You'll receive practical insights from leaders who've successfully navigated to the top of their industries!`;
  }

  // Pricing and cost queries with detailed breakdown
  if (lowerQuery.includes('cost') || lowerQuery.includes('price') || lowerQuery.includes('fee') || lowerQuery.includes('payment') || lowerQuery.includes('money')) {
    return `**Iron Lady Program Investment & Pricing:**

**💰 Program Pricing Structure:**

**🥇 Leadership Essentials Program (LEP)**
• **Investment:** ₹35,000 + GST
• **Duration:** 4 weeks + 1 year community
• **Value:** Master 27 Business War Tactics + TISS Certification
• **ROI:** Foundation for unapologetic leadership growth

**🥈 100 Board Members Program**
• **Investment:** ₹75,000 + GST
• **Duration:** 6 months comprehensive
• **Value:** Board-ready positioning + NSDC Certification
• **ROI:** Average participants achieve 100%+ salary increases

**🥉 Master of Business Warfare (MBW)**
• **Investment:** Premium executive program pricing
• **Duration:** Intensive with ongoing support
• **Value:** C-suite positioning + NASSCOM Certification
• **ROI:** Target 1+ Crore income breakthrough

**💡 Investment Perspective:**
• **ROI Success Stories:**
  - 170% salary hike (Anu Kannan - Bank of America VP)
  - 100% CTC increase in 8 months (Sushma Patil)
  - C-suite positions (Harvinder Kaur - CFO Rajasthan Royals)
  - Business scaling success (Pushpalatha M.S)

**🎓 All Programs Include:**
• Prestigious institutional certifications
• Expert mentorship from ex-CEOs
• Lifetime community access (78,000+ women)
• Comprehensive learning materials
• Real-world application support

**💳 Flexible Options:**
• Scholarship opportunities available
• Payment plans can be discussed
• Speak with counselors for personalized options

**📞 Next Steps:**
Visit iamironlady.com or speak with our counselors to understand the best investment for your career goals.

Remember: This isn't just a cost - it's an investment in your leadership future with proven ROI!`;
  }

  // Career growth and leadership queries
  if (lowerQuery.includes('career') || lowerQuery.includes('growth') || lowerQuery.includes('leadership') || lowerQuery.includes('promotion') || lowerQuery.includes('advancement')) {
    return `**Accelerate Your Career Growth with Iron Lady:**

🚀 **Career Transformation Focus:**
• Break through career plateaus and limitations
• Develop unapologetic ambition and confidence
• Master business war tactics for workplace success
• Build executive presence and leadership skills

💼 **Target Outcomes:**
• **Fast-track promotions** to leadership roles
• **Salary increases** and better opportunities
• **Board-ready positioning** for senior executives
• **Entrepreneurial success** for business owners

🎯 **Who Benefits Most:**
• Professionals aspiring for growth
• Entrepreneurs and business women
• Women seeking career change or restart
• Mid to senior-level professionals targeting C-suite

**Success Stories:**
Women in our programs have achieved 1+ Crore income breakthroughs, board positions, and successful business scaling.

Which career goal are you focusing on?`;
  }

  // Business and entrepreneurship queries
  if (lowerQuery.includes('business') || lowerQuery.includes('entrepreneur') || lowerQuery.includes('startup') || lowerQuery.includes('company')) {
    return `**Iron Lady for Business Women & Entrepreneurs:**

💪 **Business War Tactics for Women:**
• Navigate stereotypes, biases, and politics in business
• Develop strategic thinking and execution skills
• Master negotiation and deal-making
• Build influential networks and partnerships

🏆 **Entrepreneurial Success Support:**
• Scale operations and business growth
• Develop leadership teams and culture
• Strategic planning and market positioning
• Access to mentor network and peer connections

**Real Business Results:**
• **Pushpalatha M.S** scaled operations with co-founder Dr. Asha Vijay
• Multiple women achieved 1+ Crore income breakthroughs
• Business transformations across various industries

**Best Programs for Business Women:**
• **100 Board Members** - For scaling to board positions
• **Master of Business Warfare** - For C-suite aspirants and 1+ Crore income goals

Ready to transform your business leadership approach?`;
  }

  // Community and networking queries
  if (lowerQuery.includes('community') || lowerQuery.includes('network') || lowerQuery.includes('connect') || lowerQuery.includes('women')) {
    return `**Join the Iron Lady Community of 78,000+ Women Leaders:**

🌟 **Our Powerful Ecosystem:**
• **78,000+ women leaders** across India and internationally
• **4,000 women** joining monthly through our programs
• **Non-judgmental environment** for ambitious women
• **Celebration and learning sessions** for mutual support

🤝 **Community Benefits:**
• Share secret business war tactics and success formulas
• Celebrate each other's ambitions and achievements
• Peer mentoring and collaborative learning
• Lifetime access to supportive network

**Community Features:**
• **Peer networking** with like-minded professionals
• **Ongoing community support** post-program completion
• **Shared experiences** of overcoming workplace challenges
• **Collaborative learning** from diverse industries

**Community Values:**
We believe in empowering women to be unapologetically ambitious. Our community focuses on "winning" without others needing to lose - it's about elevation, not competition.

Ready to connect with ambitious women like yourself?`;
  }

  // General help and fallback for Iron Lady related queries
  if (lowerQuery.includes('help') || lowerQuery.includes('iron') || lowerQuery.includes('lady') || lowerQuery.length > 5) {
    return `**I'm here to help you learn about Iron Lady! 🌟**

**Popular Questions I Can Answer:**

🎯 **Programs & Training:**
• "What programs does Iron Lady offer?"
• "What is the program duration?"
• "Are programs online or offline?"

🏆 **Certification & Credentials:**
• "Do you provide certificates?"
• "Who are the mentors and coaches?"

💼 **Career & Business:**
• "How can Iron Lady help my career?"
• "Tell me about success stories"

💰 **Investment & Enrollment:**
• "How much does it cost?"
• "How do I join Iron Lady?"

🌟 **About Iron Lady:**
• "Tell me about Iron Lady"
• "What makes you different?"

**Quick Facts:**
• **78,000+ women trained** across our programs
• **3 flagship programs**: LEP, 100 Board Members, MBW
• **Mixed format**: Online + Offline learning
• **Prestigious certifications** from TISS, NSDC, NASSCOM
• **Expert mentors** including ex-CEOs from major corporations

What specific aspect of Iron Lady would you like to know more about?`;
  }

  // Philosophy and approach queries
  if (lowerQuery.includes('philosophy') || lowerQuery.includes('approach') || lowerQuery.includes('different') || lowerQuery.includes('unique') || lowerQuery.includes('balance') || lowerQuery.includes('guilt')) {
    return `**Iron Lady's Revolutionary Philosophy:**

**🎯 Core Belief:** ${knowledgeBase.general.philosophy}

**💪 What Makes Iron Lady Different:**
• **Reject "Learn to Balance" Ideology** - We challenge the sugar-coated concept that women should "compromise," "adjust," "suffer," and "stop dreaming"
• **Address Pay Gap Reality** - ${knowledgeBase.general.payGap}
• **Unapologetic Ambition** - We enable women to develop a mindset towards "Winning" where winning doesn't mean others need to lose
• **Business War Tactics** - ${knowledgeBase.general.uniqueApproach}

**🚀 Revolutionary Concepts We Teach:**
• **Maximization vs Balancing** - Focus on maximizing potential rather than constant balancing
• **Shameless Pitching** - Learn to present confidently without guilt
• **Unapologetic Mindset** - Develop unwavering confidence in your ambitions
• **Strategic Excellence** - Master board-level thinking and execution

**🌟 Our Mission:** ${knowledgeBase.general.mission}

**🏆 What Sets Us Apart:**
• Address stereotypes, biases, politics head-on
• Non-judgmental community of ambitious women
• Combine practical strategies with mindset transformation
• Real-world application through experienced mentors
• Focus on breakthrough, fast-track growth rather than slow traditional development

Ready to embrace unapologetic ambition? Join 78,000+ women who've transformed their careers!`;
  }

  // Testimonials and success stories with categories
  if (lowerQuery.includes('success') || lowerQuery.includes('testimonial') || lowerQuery.includes('review') || lowerQuery.includes('result') || lowerQuery.includes('story')) {
    const testimonialsByCategory = knowledgeBase.detailedTestimonials.reduce((acc, testimonial) => {
      if (!acc[testimonial.category]) acc[testimonial.category] = [];
      acc[testimonial.category].push(testimonial);
      return acc;
    }, {} as Record<string, typeof knowledgeBase.detailedTestimonials>);

    return `**Real Success Stories from Iron Lady Women:**

**💼 C-Suite & Leadership Success:**
${testimonialsByCategory["C-Suite Success"]?.map(t => `🌟 **${t.name}:** "${t.quote}"`).join('\n\n')}

**💰 Career Breakthroughs & Salary Increases:**
${testimonialsByCategory["Career Breakthrough"]?.map(t => `🌟 **${t.name}:** "${t.quote}"`).join('\n\n')}

**🚀 Fast-Track Growth:**
${testimonialsByCategory["Fast-Track Growth"]?.map(t => `🌟 **${t.name}:** "${t.quote}"`).join('\n\n')}

**🏆 Leadership Achievements:**
${testimonialsByCategory["Leadership Achievement"]?.map(t => `🌟 **${t.name}:** "${t.quote}"`).join('\n\n')}
${testimonialsByCategory["Achievement"]?.map(t => `🌟 **${t.name}:** "${t.quote}"`).join('\n\n')}

**💪 Personal Transformation:**
${testimonialsByCategory["Personal Transformation"]?.map(t => `🌟 **${t.name}:** "${t.quote}"`).join('\n\n')}
${testimonialsByCategory["Mindset Transformation"]?.map(t => `🌟 **${t.name}:** "${t.quote}"`).join('\n\n')}

**📊 Quantified Success Metrics:**
${knowledgeBase.general.successMetrics.map(metric => `• ${metric}`).join('\n')}

**🏅 Recognition:** ${knowledgeBase.general.recognition}

These aren't just stories - they're proof that Iron Lady's Business War Tactics create real, measurable results for women's careers!

Which transformation story inspires you most?`;
  }

  // Gender equality and bias queries
  if (lowerQuery.includes('bias') || lowerQuery.includes('gender') || lowerQuery.includes('equality') || lowerQuery.includes('discrimination') || lowerQuery.includes('workplace politics')) {
    return `**Iron Lady's Stand on Gender Equality & Workplace Bias:**

**🎯 The Reality We Address:**
• ${knowledgeBase.general.payGap}
• Gender biases, politics and stereotypes at workplace
• The "glass ceiling" that limits women's growth
• Ideology of "Learn to Balance" imposed on women
• Women made to feel "Guilty" for dreaming big

**💪 How Iron Lady Fights Gender Bias:**
• **Business War Tactics** - Strategies to navigate and overcome workplace politics
• **Unapologetic Mindset Training** - Reject guilt about being ambitious
• **Strategic Excellence** - Master board-level thinking to transcend limitations
• **Shameless Pitching** - Present ideas confidently without traditional female hesitation
• **Extreme Signalling** - Learn influential communication that commands respect

**🏆 Rajesh Bhat's Revolutionary Stand:**
Our Founder Rajesh Bhat's bold choice to wear a saree in professional settings has sparked global conversations and challenged stereotypes, amplifying the discourse on gender equality. This earned him recognition from Amitabh Bachchan and CNN, who named him one of 'The Real Heroes of India.'

**🚀 Real Results Against Bias:**
• **Harvinder Kaur** - Only woman on Rajasthan Royals IPL team, thrived as CFO
• **Anu Kannan** - 170% hike despite gender challenges at Bank of America
• **Multiple women** achieving C-suite positions in male-dominated industries

**💡 Our Philosophy:**
We believe in empowering women to be unapologetically ambitious. Our approach focuses on "winning" without others needing to lose - it's about elevation of women, not competition against men.

**🌟 Join the Movement:**
78,000+ women have already broken through gender barriers with Iron Lady. You can be next!

Ready to master tactics that help you win without fighting bias?`;
  }

  // Company and organizational queries
  if (lowerQuery.includes('company') || lowerQuery.includes('organization') || lowerQuery.includes('founded') || lowerQuery.includes('history') || lowerQuery.includes('magic wand')) {
    return `**About Iron Lady Organization:**

**🏢 Company Details:**
• **Full Company Name:** ${knowledgeBase.general.company}
• **Founded:** ${knowledgeBase.general.founding}
• **Focus:** ${knowledgeBase.general.focus}
• **Mission:** ${knowledgeBase.general.mission}

**📈 Organizational Impact:**
• **Trained:** 78,000+ women leaders across India and internationally
• **Current Scale:** Training 4,000 women monthly
• **Community Size:** 78,000+ active women leaders ecosystem
• **Recognition:** ${knowledgeBase.general.recognition}

**👥 Leadership Team:**
• **5 World-class leaders** with 100+ years combined C-suite experience
• **Ex-CEOs** from Aviva Singapore, Bajaj Auto, Escorts
• **Global experience** across Barclays, Prudential, Hong Leong Bank, PepsiCo, Britannia
• **Innovation expertise** from Infosys, Robert Bosch, Philips

**🌍 Global Recognition:**
• Rajesh Bhat recognized by CNN as 'Real Hero of India'
• Acknowledged by Amitabh Bachchan for gender equality work
• TEDx speaking engagements
• International media coverage for innovative approaches

**🏆 Certifications & Partnerships:**
• **TISS** - Tata Institute of Social Sciences
• **NSDC** - National Skill Development Corporation
• **NASSCOM Foundation** - Leading IT industry body

**💡 Organizational Philosophy:**
Iron Lady represents a movement beyond traditional leadership training. We're revolutionizing how women approach career growth by challenging societal norms and empowering unapologetic ambition.

**🚀 Future Vision:**
Working towards elevating a million women to the top through systematic application of Business War Tactics and breakthrough methodologies.

Ready to be part of India's largest women's leadership transformation movement?`;
  }

  // Fallback with comprehensive help
  return `**I understand you're asking about "${query}"** 

**🌟 I'm your Iron Lady AI Assistant with comprehensive knowledge about:**

**📚 Programs & Training:**
• Leadership Essentials Program (LEP) - ₹35,000 + GST
• 100 Board Members Program - ₹75,000 + GST  
• Master of Business Warfare (MBW) - Elite program
• Program structures, modules, outcomes, and methodologies

**👥 Expert Team & Mentorship:**
• Rajesh Bhat (Founder, TEDx Speaker, CNN Hero)
• Suvarna Hegde (CEO, Business War Tactics Expert)
• Simon Newman (Ex-CEO Aviva Singapore)
• Sridhar Sambandam (Ex-CEO Bajaj Auto)
• Chitra Talwar (Ex-VP PepsiCo)

**💪 Business War Tactics:**
• All 27 Business War Tactics we teach
• Shameless pitching, Strategic maximization
• Unapologetic mindset, Extreme signalling
• Upside-down thinking, Board-level excellence

**🏆 Success Stories & Results:**
• 170% salary hikes, 100% CTC increases
• C-suite achievements, Board positions
• 1+ Crore income breakthroughs
• Business scaling successes

**🎯 Philosophy & Approach:**
• Gender equality and bias combat strategies
• "Maximization vs Balance" methodology
• Community of 78,000+ women leaders
• Anti-guilt, pro-ambition mindset

**💰 Investment & Enrollment:**
• Detailed pricing and ROI information
• Scholarship opportunities
• Enrollment process and next steps

**Try asking me:**
• "Tell me about Leadership Essentials Program"
• "What are Business War Tactics?"
• "Show me success stories"
• "How much does it cost?"
• "Who are the mentors?"
• "How does Iron Lady fight gender bias?"

**📞 Ready to Transform Your Career?**
Visit iamironlady.com or speak with our counselors for personalized guidance!

What specific aspect of Iron Lady's offerings interests you most?`;
}
