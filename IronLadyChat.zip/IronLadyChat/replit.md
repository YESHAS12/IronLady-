# Overview

This is a full-stack web application for Iron Lady, a women's leadership development organization. The application features an AI-powered chatbot that helps users learn about Iron Lady's leadership programs and provides guidance. The system combines a React frontend with an Express.js backend, using modern web technologies and UI components.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite for build tooling
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Component Structure**: Organized into reusable UI components and feature-specific components

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints for chat functionality
- **Session Management**: UUID-based chat sessions
- **Storage Pattern**: Interface-based storage with in-memory implementation (MemStorage)
- **Development Setup**: Integrated Vite development server with hot module replacement

## Data Layer
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Database Provider**: Neon serverless PostgreSQL
- **Current Implementation**: In-memory storage for development with database schema ready for production

## Key Features
- **Chat Interface**: Real-time messaging with AI-powered responses
- **Program Information**: Dedicated sidebar showcasing Iron Lady's three main programs
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Session Management**: Persistent chat sessions with message history
- **TypeScript Safety**: Shared types between frontend and backend

## AI Integration
- **Service**: OpenAI GPT integration with knowledge base fallback
- **Knowledge Base**: Static information about Iron Lady programs and mentors
- **Response Strategy**: Hybrid approach using local knowledge base for quick responses and OpenAI for complex queries
- **Context Awareness**: Conversation history maintained for contextual responses

# External Dependencies

## Core Technologies
- **Database**: Neon PostgreSQL serverless database
- **AI Service**: OpenAI API for chat responses
- **Build Tools**: Vite for frontend bundling and development server
- **Package Manager**: npm with lock file for consistent builds

## UI and Styling
- **Component Library**: Radix UI primitives for accessible components
- **Styling Framework**: Tailwind CSS for utility-first styling
- **Icons**: Lucide React for consistent iconography
- **Fonts**: Google Fonts (Inter, DM Sans, Geist Mono, etc.)

## Development Tools
- **Type Checking**: TypeScript for static type analysis
- **Database Tools**: Drizzle Kit for schema management and migrations
- **Development**: Replit-specific plugins for runtime error handling and debugging
- **Build Process**: ESBuild for server-side bundling in production

## Third-Party Services
- **Session Storage**: Connect-pg-simple for PostgreSQL session storage
- **Date Handling**: date-fns for date manipulation
- **Validation**: Zod for runtime type validation
- **Form Handling**: React Hook Form with resolvers for form management