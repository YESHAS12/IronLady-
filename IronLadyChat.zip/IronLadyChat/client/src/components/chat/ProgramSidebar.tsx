import { Card } from "@/components/ui/card";

export function ProgramSidebar() {
  return (
    <aside className="hidden lg:block w-80 bg-sidebar border-r border-sidebar-border">
      <div className="p-6 space-y-6">
        <div>
          <h2 className="text-lg font-semibold text-sidebar-foreground mb-4">Our Programs</h2>
          <div className="space-y-4">
            {/* Leadership Essentials Program */}
            <Card className="p-4 bg-sidebar-accent border-0">
              <h3 className="font-medium text-sidebar-accent-foreground text-sm">Leadership Essentials Program</h3>
              <p className="text-xs text-sidebar-foreground/70 mt-1">Build unapologetic ambition and maximize your potential</p>
              <div className="flex items-center mt-2 text-xs text-accent">
                <span>✓ TISS Certified</span>
              </div>
            </Card>

            {/* 100 Board Members Program */}
            <Card className="p-4 bg-sidebar-accent border-0">
              <h3 className="font-medium text-sidebar-accent-foreground text-sm">100 Board Members Program</h3>
              <p className="text-xs text-sidebar-foreground/70 mt-1">Fast-track your career growth with innovative techniques</p>
              <div className="flex items-center mt-2 text-xs text-accent">
                <span>✓ NSDC Certified</span>
              </div>
            </Card>

            {/* Master of Business Warfare */}
            <Card className="p-4 bg-sidebar-accent border-0">
              <h3 className="font-medium text-sidebar-accent-foreground text-sm">Master of Business Warfare</h3>
              <p className="text-xs text-sidebar-foreground/70 mt-1">C-suite strategies for 1+ Crore income breakthrough</p>
              <div className="flex items-center mt-2 text-xs text-accent">
                <span>✓ NASSCOM Certified</span>
              </div>
            </Card>
          </div>
        </div>

        <div>
          <h3 className="font-medium text-sidebar-foreground mb-3">Quick Stats</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-sidebar-foreground/70">Women Trained:</span>
              <span className="font-medium text-sidebar-foreground">78,000+</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sidebar-foreground/70">Format:</span>
              <span className="font-medium text-sidebar-foreground">Online & Offline</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sidebar-foreground/70">Certification:</span>
              <span className="font-medium text-sidebar-foreground">Yes</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sidebar-foreground/70">Mentorship:</span>
              <span className="font-medium text-sidebar-foreground">1-on-1</span>
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-medium text-sidebar-foreground mb-3">Expert Mentors</h3>
          <div className="space-y-2 text-xs">
            <div className="text-sidebar-foreground/70">• Simon Newman (Ex-CEO, Aviva Singapore)</div>
            <div className="text-sidebar-foreground/70">• Sridhar Sambandam (Ex-CEO, Bajaj Auto)</div>
            <div className="text-sidebar-foreground/70">• Suvarna Hegde (Founder & CEO)</div>
            <div className="text-sidebar-foreground/70">• Rajesh Bhat (Founder/Director)</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
