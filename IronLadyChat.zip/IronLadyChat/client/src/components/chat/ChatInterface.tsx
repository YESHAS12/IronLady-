import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ChatMessage } from "./ChatMessage";
import { ChatMessage as ChatMessageType } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Send, ExternalLink } from "lucide-react";

interface ChatInterfaceProps {
  sessionId: string;
}

export function ChatInterface({ sessionId }: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch chat messages
  const { data: messagesData, isLoading } = useQuery({
    queryKey: ["/api/chat/sessions", sessionId, "messages"],
    enabled: !!sessionId,
  });

  const messages = (messagesData as { messages?: ChatMessageType[] })?.messages || [];

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/chat/messages", {
        sessionId,
        message: content,
      });
      return response.json();
    },
    onMutate: () => {
      setIsTyping(true);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/sessions", sessionId, "messages"] });
      setMessage("");
      setIsTyping(false);
    },
    onError: (error) => {
      console.error("Error sending message:", error);
      setIsTyping(false);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (content: string) => {
    if (!content.trim() || sendMessageMutation.isPending) return;
    sendMessageMutation.mutate(content.trim());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(message);
  };

  const handleQuickMessage = (quickMessage: string) => {
    handleSendMessage(quickMessage);
  };

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  return (
    <main className="flex-1 flex flex-col" data-testid="chat-interface">
      <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full">
        
        {/* Chat Header */}
        <div className="p-4 border-b border-border bg-card">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-foreground">Ask me about Iron Lady Programs</h2>
              <p className="text-sm text-muted-foreground">Get instant answers about our leadership programs, duration, certification, and more</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground text-sm font-medium">AI</span>
                </div>
                <div className="hidden sm:flex items-center space-x-2 text-sm text-muted-foreground">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>AI Assistant Online</span>
                </div>
              </div>
              <a 
                href="https://iamironlady.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center space-x-1 text-primary hover:text-primary/80 text-sm font-medium"
                data-testid="link-visit-website"
              >
                <span>Visit Iron Lady</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        {/* Chat Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 chat-scroll" data-testid="messages-container">
          
          {/* Welcome Message */}
          <div className="flex items-start space-x-3 slide-up">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-primary-foreground text-sm font-medium">AI</span>
            </div>
            <div className="flex-1">
              <Card className="p-4 shadow-sm">
                <p className="text-foreground">👋 Welcome to Iron Lady! I'm here to help you learn about our leadership programs for women. You can ask me about:</p>
                <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                  <li>• Program details and duration</li>
                  <li>• Online vs offline formats</li>
                  <li>• Certification information</li>
                  <li>• Mentors and coaching</li>
                  <li>• Program recommendations</li>
                </ul>
              </Card>
              <span className="text-xs text-muted-foreground mt-1 block">Just now</span>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap gap-2 px-11">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => handleQuickMessage('What programs does Iron Lady offer?')}
              disabled={sendMessageMutation.isPending}
              data-testid="button-quick-programs"
            >
              What programs do you offer?
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => handleQuickMessage('What is the program duration?')}
              disabled={sendMessageMutation.isPending}
              data-testid="button-quick-duration"
            >
              Program duration?
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => handleQuickMessage('Are the programs online or offline?')}
              disabled={sendMessageMutation.isPending}
              data-testid="button-quick-format"
            >
              Online or offline?
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => handleQuickMessage('Do you provide certificates?')}
              disabled={sendMessageMutation.isPending}
              data-testid="button-quick-certificates"
            >
              Certificates provided?
            </Button>
          </div>

          {/* Chat Messages */}
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-muted-foreground">Loading messages...</div>
            </div>
          ) : (
            messages.map((msg: ChatMessageType) => (
              <ChatMessage key={msg.id} message={msg} />
            ))
          )}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-start space-x-3 slide-up">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-primary-foreground text-sm font-medium">AI</span>
              </div>
              <div className="flex-1">
                <Card className="p-4 shadow-sm">
                  <div className="bounce-dots">
                    <div></div>
                    <div></div>
                    <div></div>
                  </div>
                </Card>
                <span className="text-xs text-muted-foreground mt-1 block">Typing...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <div className="p-4 border-t border-border bg-card">
          <form onSubmit={handleSubmit} className="flex space-x-3">
            <div className="flex-1">
              <Input 
                type="text" 
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Ask me anything about Iron Lady programs..." 
                className="w-full"
                disabled={sendMessageMutation.isPending}
                data-testid="input-message"
              />
            </div>
            <Button 
              type="submit" 
              disabled={sendMessageMutation.isPending || !message.trim()}
              data-testid="button-send"
            >
              <Send className="w-4 h-4 mr-1" />
              Send
            </Button>
          </form>
          <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
            <span>Powered by OpenAI & Iron Lady Knowledge Base</span>
            <span>Press Enter to send</span>
          </div>
        </div>

      </div>
    </main>
  );
}
