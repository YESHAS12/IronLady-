import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { ChatInterface } from "@/components/chat/ChatInterface";
import { ProgramSidebar } from "@/components/chat/ProgramSidebar";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ChatPage() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const { toast } = useToast();

  // Create chat session mutation
  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/chat/sessions", {});
      return response.json();
    },
    onSuccess: (data) => {
      setSessionId(data.sessionId);
    },
    onError: (error) => {
      console.error("Error creating session:", error);
      toast({
        title: "Error",
        description: "Failed to start chat session. Please refresh the page.",
        variant: "destructive",
      });
    },
  });

  // Create session on component mount
  useEffect(() => {
    if (!sessionId) {
      createSessionMutation.mutate();
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col" data-testid="chat-page">
      
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              {/* Iron Lady logo and branding */}
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-lg">IL</span>
                </div>
                <div>
                  <h1 className="text-lg font-semibold text-foreground">Iron Lady AI Assistant</h1>
                  <p className="text-xs text-muted-foreground">Leadership Program Guidance</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex items-center space-x-2 text-sm text-muted-foreground">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>AI Assistant Online</span>
              </div>
              <a 
                href="https://iamironlady.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:text-primary/80 text-sm font-medium"
                data-testid="link-header-website"
              >
                Visit Iron Lady →
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex">
        <ProgramSidebar />
        
        {/* Chat Interface */}
        {sessionId ? (
          <ChatInterface sessionId={sessionId} />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full animate-spin mx-auto mb-2"></div>
              <p className="text-muted-foreground">Starting your chat session...</p>
            </div>
          </div>
        )}
      </div>

    </div>
  );
}
