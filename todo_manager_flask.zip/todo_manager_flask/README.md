
# To‑Do Manager (Flask + SQLite)

A clean, beginner‑friendly CRUD app with a bonus **Smart Generate** feature.
- Create, read, update, delete tasks
- Status (pending/done)
- **Quick Suggestion**: adds a random productivity task
- **Smart Generate**: turns your goal into N actionable tasks
  - Uses OpenAI if `OPENAI_API_KEY` is set (and `openai` package installed)
  - Otherwise uses a built‑in smart fallback (no internet needed)

---

## 1) Tech Stack
- Python 3.8+
- Flask (web)
- SQLite (built‑in)

## 2) Folder Structure
```text
todo_manager_flask/
├─ app/
│  ├─ __init__.py        # App factory + DB path
│  ├─ models.py          # SQLite CRUD helpers
│  ├─ routes.py          # Flask routes / views
│  ├─ ai.py              # Optional OpenAI + fallback generator
│  ├─ templates/
│  │  ├─ base.html
│  │  └─ index.html
│  └─ static/
│     └─ css/
│        └─ styles.css
├─ instance/             # Created automatically; holds todo.db
├─ run.py                # Entry point
├─ requirements.txt      # Minimal deps (Flask)
└─ README.md
```

## 3) How to Run (Step‑by‑Step, No Hiccups)

### A. Windows (PowerShell)
```powershell
cd todo_manager_flask
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run.py
```
Open http://127.0.0.1:5000 in your browser.

### B. macOS / Linux
```bash
cd todo_manager_flask
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 run.py
```
Open http://127.0.0.1:5000 in your browser.

### Optional: Enable real OpenAI generation
1) Install the OpenAI package:
```bash
pip install openai
```
2) Set your API key in the terminal (replace `sk-...` with your key):
- Windows (PowerShell):
  ```powershell
  setx OPENAI_API_KEY "sk-..."
  # then close & reopen the terminal (or use $env:OPENAI_API_KEY for current session)
  $env:OPENAI_API_KEY = "sk-..."
  ```
- macOS / Linux:
  ```bash
  export OPENAI_API_KEY="sk-..."
  ```
3) Restart the app. The **Smart Generate** button will now use OpenAI.

## 4) Features Implemented
- CRUD: Add, view, update (title/description/status), delete tasks
- List sorted by newest first
- Quick Suggestion (one‑click useful task)
- Smart Generate (N tasks from your goal) with AI fallback
- Bootstrap 5 styling

## 5) Notes
- The SQLite database file lives at `instance/todo.db` and is created automatically.
- No migrations needed. Delete `instance/todo.db` to reset data.
- For production, set a real `SECRET_KEY` in `app/__init__.py` or via env var.
