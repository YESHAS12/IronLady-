
import os
import re
import random

# Optional OpenAI support (only used if available + API key set)
_openai_client = None
try:
    from openai import OpenAI  # type: ignore
    if os.getenv("OPENAI_API_KEY"):
        _openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
except Exception:
    _openai_client = None

BASIC_SUGGESTIONS = [
    ("Read a book", "Spend 20 minutes reading your current book."),
    ("Workout", "Do a 15–20 minute bodyweight routine."),
    ("Plan tomorrow", "Write a 3-item priority list for tomorrow."),
    ("Tidy workspace", "Clear your desk and file any loose papers."),
    ("Drink water", "Refill your bottle and drink 500 ml."),
    ("Inbox zero", "Archive or reply to the top 10 emails."),
    ("Review notes", "Revisit yesterday's notes and highlight key points."),
]

def _heuristic_breakdown(prompt: str, n: int = 3):
    """Very small heuristic 'AI-lite' that turns a goal into subtasks."""
    prompt = prompt.strip()
    if not prompt:
        tasks = [random.choice(BASIC_SUGGESTIONS)]
        return tasks

    # Extract keywords as a simple 'summary'
    words = re.findall(r"[\w']+", prompt.lower())
    keywords = [w for w in words if len(w) > 3][:5]
    base = " ".join(sorted(set(keywords))) or "general"

    templates = [
        ("Research: " + base, f"Skim 2–3 short articles/videos about {base} and take quick notes."),
        ("Plan: " + base, f"List 3 concrete steps to progress on {base}."),
        ("Do first step: " + base, f"Spend 25 minutes focused on the first step for {base} (Pomodoro)."),
        ("Review & next: " + base, f"Write one sentence about progress and pick the next action for {base}."),
    ]
    random.shuffle(templates)
    tasks = templates[: max(1, min(n, len(templates)))]
    return tasks

def generate_tasks(prompt: str, n: int = 3):
    """Return a list of (title, description) tuples.

    Uses OpenAI if available; otherwise falls back to a heuristic generator.

    """
    n = max(1, min(int(n or 3), 10))
    if _openai_client:
        try:
            resp = _openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You turn one goal into short actionable to-do items."},
                    {"role": "user", "content": f"Goal: {prompt}\nMake {n} concise tasks as JSON list of objects with 'title' and 'description'."}
                ],
                temperature=0.4
            )
            text = resp.choices[0].message.content.strip()
            import json
            items = json.loads(text)
            out = []
            for it in items[:n]:
                title = str(it.get("title","Task")).strip()[:120]
                desc = str(it.get("description",""))
                out.append((title, desc[:400]))
            if out:
                return out
        except Exception:
            pass  # fall back if anything goes wrong
    # Fallback
    return _heuristic_breakdown(prompt, n)
