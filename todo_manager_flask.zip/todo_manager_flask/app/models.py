
import sqlite3

def get_connection(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(db_path):
    conn = get_connection(db_path)
    cur = conn.cursor()
    cur.execute("""            CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'pending'
        )
    """)
    conn.commit()
    conn.close()

def list_tasks(db_path):
    conn = get_connection(db_path)
    cur = conn.cursor()
    cur.execute("SELECT id, title, description, status FROM tasks ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    return rows

def create_task(db_path, title, description=""):
    conn = get_connection(db_path)
    cur = conn.cursor()
    cur.execute("INSERT INTO tasks (title, description) VALUES (?, ?)", (title, description))
    conn.commit()
    conn.close()

def update_task(db_path, task_id, title, description, status="pending"):
    conn = get_connection(db_path)
    cur = conn.cursor()
    cur.execute("UPDATE tasks SET title=?, description=?, status=? WHERE id=?", (title, description, status, task_id))
    conn.commit()
    conn.close()

def delete_task(db_path, task_id):
    conn = get_connection(db_path)
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id=?", (task_id,))
    conn.commit()
    conn.close()
