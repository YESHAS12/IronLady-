
import os
from flask import Flask
from .models import init_db

def create_app():
    app = Flask(__name__, instance_relative_config=True)

    # Ensure instance folder exists (for SQLite DB)
    try:
        os.makedirs(app.instance_path, exist_ok=True)
    except OSError:
        pass

    app.config.from_mapping(
        SECRET_KEY="dev",  # replace in production
        DATABASE=os.path.join(app.instance_path, "todo.db"),
    )

    # Initialize DB (create table if not exists)
    init_db(app.config["DATABASE"])

    # Register routes
    from .routes import bp as routes_bp
    app.register_blueprint(routes_bp)

    return app
