
from flask import Blueprint, render_template, request, redirect, url_for, current_app, flash
from .models import list_tasks, create_task, update_task, delete_task
from .ai import generate_tasks, BASIC_SUGGESTIONS
import random

bp = Blueprint("routes", __name__)

@bp.route("/", methods=["GET"])
def index():
    tasks = list_tasks(current_app.config["DATABASE"])
    return render_template("index.html", tasks=tasks)

@bp.route("/tasks/add", methods=["POST"])
def add_task():
    title = request.form.get("title","").strip()
    description = request.form.get("description","").strip()
    if not title:
        flash("Title is required.", "danger")
        return redirect(url_for("routes.index"))
    create_task(current_app.config["DATABASE"], title, description)
    flash("Task added.", "success")
    return redirect(url_for("routes.index"))

@bp.route("/tasks/<int:task_id>/update", methods=["POST"])
def edit_task(task_id):
    title = request.form.get("title","").strip()
    description = request.form.get("description","").strip()
    status = request.form.get("status","pending").strip()
    if not title:
        flash("Title is required.", "danger")
        return redirect(url_for("routes.index"))
    update_task(current_app.config["DATABASE"], task_id, title, description, status)
    flash("Task updated.", "info")
    return redirect(url_for("routes.index"))

@bp.route("/tasks/<int:task_id>/delete", methods=["POST"])
def remove_task(task_id):
    delete_task(current_app.config["DATABASE"], task_id)
    flash("Task deleted.", "warning")
    return redirect(url_for("routes.index"))

@bp.route("/generate/quick", methods=["POST"])
def quick_generate():
    suggestion = random.choice(BASIC_SUGGESTIONS)
    create_task(current_app.config["DATABASE"], suggestion[0], suggestion[1])
    flash("Quick suggestion added.", "success")
    return redirect(url_for("routes.index"))

@bp.route("/generate/ai", methods=["POST"])
def ai_generate():
    prompt = request.form.get("goal","").strip()
    n = request.form.get("count","3").strip()
    try:
        n_int = int(n)
    except Exception:
        n_int = 3
    pairs = generate_tasks(prompt, n_int)
    for title, desc in pairs:
        create_task(current_app.config["DATABASE"], title, desc)
    flash(f"Added {len(pairs)} smart task(s).", "success")
    return redirect(url_for("routes.index"))
